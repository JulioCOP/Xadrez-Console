﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Xadrez_Console.tabuleiro
{
    enum Cor
    {
        Branca,
        Preta,
        Amarela,
        Azul,
        Verde,
        Laranja,
        Vermelho,
        Roxo
    }
}
